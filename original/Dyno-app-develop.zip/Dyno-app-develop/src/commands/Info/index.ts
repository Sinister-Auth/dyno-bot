export {default as Info} from './Info';
export {default as Ping} from './Ping';
export {default as Premium} from './Premium';
export {default as Stats} from './Stats';
export {default as Support} from './Support';
export {default as Uptime} from './Uptime';
