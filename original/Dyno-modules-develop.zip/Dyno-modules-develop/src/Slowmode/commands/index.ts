export {default as Slowmode} from './Slowmode';
