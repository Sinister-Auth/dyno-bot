interface Reminder {
	_id: string;
	content: string;
	server: string;
	user: string;
}