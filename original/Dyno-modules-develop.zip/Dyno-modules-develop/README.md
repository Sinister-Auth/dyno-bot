Dyno-modules
============
