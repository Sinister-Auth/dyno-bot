import React from 'react';
import ReactDOM from 'react-dom';
import Status from './Status.jsx';

ReactDOM.render(
    <Status />,
    document.getElementById('status-mount'),
);
