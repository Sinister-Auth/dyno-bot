# dyno-image-generation

Please refer to https://github.com/Automattic/node-canvas for instructions on installing dependecies for node-canvas.

NATS must be running on the host for this to communicate properly.