export const Navbar = {
    navBarCustomView: 'dyno.Navbar'
};