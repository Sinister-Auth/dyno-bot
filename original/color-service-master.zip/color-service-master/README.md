# Dyno color service

This service generates generic colored dyno logos