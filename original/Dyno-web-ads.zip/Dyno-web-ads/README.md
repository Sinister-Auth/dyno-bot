Dyno-Web
========

Web server for Dyno

## How to build the relevant asset files:
### React
1. go to the /react dir
2. run `npm install` or `yarn` to get the dependencies
3. run `npm run build:prod` or `yarn build:prod` to build a production optimized version of the react component
4. You should now find some js files in `/public/js/react/`
