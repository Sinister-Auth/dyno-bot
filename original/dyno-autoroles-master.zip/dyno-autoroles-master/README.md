Autoroles module for Dyno
=========================
