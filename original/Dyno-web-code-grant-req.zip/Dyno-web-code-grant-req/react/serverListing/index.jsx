import React from 'react';
import ReactDOM from 'react-dom';
import Serverlist from './Serverlist.jsx';

ReactDOM.render(
    <Serverlist />,
    document.getElementById('serverlist-mount'),
);
