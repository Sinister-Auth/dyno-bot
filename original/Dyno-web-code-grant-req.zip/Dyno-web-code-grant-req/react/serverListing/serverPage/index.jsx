import React from 'react';
import ReactDOM from 'react-dom';
import ServerPage from './ServerPage.jsx';

ReactDOM.render(
    <ServerPage />,
    document.getElementById('serverpage-mount'),
);
