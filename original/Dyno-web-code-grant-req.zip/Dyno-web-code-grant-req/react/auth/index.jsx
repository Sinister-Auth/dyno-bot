import React from 'react';
import ReactDOM from 'react-dom';
import Auth from './Auth.jsx';

ReactDOM.render(
    <Auth />,
    document.getElementById('auth-mount'),
);
